.. vollib documentation master file, created by
   sphinx-quickstart on Wed Apr  1 19:21:03 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../vollib/README.MD


Contents:
=========
.. toctree::
   :caption: Table of Contents
   :name: mastertoc


.. toctree::
   :maxdepth: 1

.. toctree::
   :titlesonly:
   
  

   vollib modules <apidoc/modules.rst>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

